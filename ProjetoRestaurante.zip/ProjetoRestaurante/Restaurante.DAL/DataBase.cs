﻿using Restaurante.DTO;

namespace Restaurante.DAL
{
    public class DataBase
    {
        
        public static List<BebidaDTO> Bebidas
        {
            get => JsonDataBase.Ler<BebidaDTO>("Bebidas.json");
            set => JsonDataBase.Salvar("Bebidas.json", value);
        }
        public static List<CargoDTO> Cargos
        {
            get => JsonDataBase.Ler<CargoDTO>("Cargos.json");
            set => JsonDataBase.Salvar("Cargos.json", value);
        }
   
        
        public static List<PratoDTO> Pratos
        {
            get => JsonDataBase.Ler<PratoDTO>("Pratos.json");
            set => JsonDataBase.Salvar("Pratos.json", value);
        }
        public static List<UsuarioDTO> Usuarios
        {

            get => JsonDataBase.Ler<UsuarioDTO>("Usuarios.json");
            set => JsonDataBase.Salvar("Usuarios.json", value);
        }
        
        public static List<SobremesaDTO> Sobremesas
        {
            get => JsonDataBase.Ler<SobremesaDTO>("Sobremesas.json");
            set => JsonDataBase.Salvar("Sobremesas.json", value);
        }
    }
}

