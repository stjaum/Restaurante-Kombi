﻿using System.Text.Json;
using Restaurante.DTO;

namespace Restaurante.DAL
{
    public static class JsonDataBase
    {
        private static readonly string DataFolder = Path.Combine(Environment.CurrentDirectory, "Data");

        static JsonDataBase()
        {
            if (!Directory.Exists(DataFolder))
            {
                Directory.CreateDirectory(DataFolder);
            }

        }
        public static List<T> Ler<T>(string NomeArquivo) where T : class
        {
            string path = Path.Combine(DataFolder, NomeArquivo);

            if (!File.Exists(path))
            {
                File.WriteAllText(path, "[]");
            }

            string json = File.ReadAllText(path);

            return JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();

        }
        public static void Salvar<T>(string NomeArquivo, List<T> lista) where T : class
        {
            string path = Path.Combine(DataFolder, NomeArquivo);

            string json = JsonSerializer.Serialize(lista, new JsonSerializerOptions { WriteIndented = true, });

            File.WriteAllText(path, json);

        }

    }
}
