﻿namespace Restaurante.UI
{
    partial class frmPratos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            dgProdutos = new Guna.UI2.WinForms.Guna2DataGridView();
            txtPesquisar = new Guna.UI2.WinForms.Guna2TextBox();
            pictureBox1 = new PictureBox();
            txtCod = new Guna.UI2.WinForms.Guna2TextBox();
            txtNome = new Guna.UI2.WinForms.Guna2TextBox();
            txtPreco = new Guna.UI2.WinForms.Guna2TextBox();
            btnExcluir = new Guna.UI2.WinForms.Guna2Button();
            btnAtualizar = new Guna.UI2.WinForms.Guna2Button();
            btnCadastrar = new Guna.UI2.WinForms.Guna2Button();
            btnFechar = new Guna.UI2.WinForms.Guna2CircleButton();
            ((System.ComponentModel.ISupportInitialize)dgProdutos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.BorderRadius = 20;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // dgProdutos
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            dgProdutos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgProdutos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgProdutos.ColumnHeadersHeight = 4;
            dgProdutos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgProdutos.DefaultCellStyle = dataGridViewCellStyle3;
            dgProdutos.GridColor = Color.FromArgb(231, 229, 255);
            dgProdutos.Location = new Point(201, 78);
            dgProdutos.Name = "dgProdutos";
            dgProdutos.RowHeadersVisible = false;
            dgProdutos.Size = new Size(487, 398);
            dgProdutos.TabIndex = 0;
            dgProdutos.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgProdutos.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgProdutos.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgProdutos.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgProdutos.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgProdutos.ThemeStyle.BackColor = Color.White;
            dgProdutos.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgProdutos.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgProdutos.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgProdutos.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            dgProdutos.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgProdutos.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgProdutos.ThemeStyle.HeaderStyle.Height = 4;
            dgProdutos.ThemeStyle.ReadOnly = false;
            dgProdutos.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgProdutos.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgProdutos.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            dgProdutos.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgProdutos.ThemeStyle.RowsStyle.Height = 25;
            dgProdutos.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgProdutos.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgProdutos.CellContentClick += dgProdutos_CellContentClick;
            // 
            // txtPesquisar
            // 
            txtPesquisar.CustomizableEdges = customizableEdges14;
            txtPesquisar.DefaultText = "";
            txtPesquisar.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPesquisar.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPesquisar.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPesquisar.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPesquisar.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPesquisar.Font = new Font("Segoe UI", 9F);
            txtPesquisar.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPesquisar.Location = new Point(201, 36);
            txtPesquisar.Name = "txtPesquisar";
            txtPesquisar.PlaceholderText = "Pesquisar";
            txtPesquisar.SelectedText = "";
            txtPesquisar.ShadowDecoration.CustomizableEdges = customizableEdges15;
            txtPesquisar.Size = new Size(487, 36);
            txtPesquisar.TabIndex = 1;
            txtPesquisar.TextChanged += txtPesquisar_TextChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.KOMBI_restaurante___bar;
            pictureBox1.Location = new Point(-55, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(303, 153);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // txtCod
            // 
            txtCod.CustomizableEdges = customizableEdges12;
            txtCod.DefaultText = "";
            txtCod.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCod.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCod.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCod.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCod.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCod.Font = new Font("Segoe UI", 9F);
            txtCod.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCod.Location = new Point(3, 209);
            txtCod.Name = "txtCod";
            txtCod.PlaceholderText = "Código";
            txtCod.SelectedText = "";
            txtCod.ShadowDecoration.CustomizableEdges = customizableEdges13;
            txtCod.Size = new Size(192, 36);
            txtCod.TabIndex = 10;
            txtCod.TextChanged += txtCod_TextChanged;
            // 
            // txtNome
            // 
            txtNome.CustomizableEdges = customizableEdges10;
            txtNome.DefaultText = "";
            txtNome.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNome.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNome.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNome.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNome.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNome.Font = new Font("Segoe UI", 9F);
            txtNome.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNome.Location = new Point(3, 251);
            txtNome.Name = "txtNome";
            txtNome.PlaceholderText = "Nome";
            txtNome.SelectedText = "";
            txtNome.ShadowDecoration.CustomizableEdges = customizableEdges11;
            txtNome.Size = new Size(192, 36);
            txtNome.TabIndex = 10;
            // 
            // txtPreco
            // 
            txtPreco.CustomizableEdges = customizableEdges8;
            txtPreco.DefaultText = "";
            txtPreco.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPreco.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPreco.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPreco.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPreco.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPreco.Font = new Font("Segoe UI", 9F);
            txtPreco.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPreco.Location = new Point(3, 293);
            txtPreco.Name = "txtPreco";
            txtPreco.PlaceholderText = "Preço";
            txtPreco.SelectedText = "";
            txtPreco.ShadowDecoration.CustomizableEdges = customizableEdges9;
            txtPreco.Size = new Size(192, 36);
            txtPreco.TabIndex = 10;
            // 
            // btnExcluir
            // 
            btnExcluir.BackColor = Color.Transparent;
            btnExcluir.BorderRadius = 20;
            btnExcluir.CustomizableEdges = customizableEdges2;
            btnExcluir.DisabledState.BorderColor = Color.DarkGray;
            btnExcluir.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExcluir.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExcluir.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExcluir.FillColor = Color.FromArgb(246, 85, 103);
            btnExcluir.Font = new Font("Ravie", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnExcluir.ForeColor = Color.Black;
            btnExcluir.Location = new Point(3, 335);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.ShadowDecoration.CustomizableEdges = customizableEdges3;
            btnExcluir.Size = new Size(192, 43);
            btnExcluir.TabIndex = 11;
            btnExcluir.Text = "Excluir";
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnAtualizar
            // 
            btnAtualizar.BackColor = Color.Transparent;
            btnAtualizar.BorderRadius = 20;
            btnAtualizar.CustomizableEdges = customizableEdges4;
            btnAtualizar.DisabledState.BorderColor = Color.DarkGray;
            btnAtualizar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAtualizar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAtualizar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAtualizar.FillColor = Color.FromArgb(239, 212, 107);
            btnAtualizar.Font = new Font("Ravie", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAtualizar.ForeColor = Color.Black;
            btnAtualizar.Location = new Point(3, 384);
            btnAtualizar.Name = "btnAtualizar";
            btnAtualizar.ShadowDecoration.CustomizableEdges = customizableEdges5;
            btnAtualizar.Size = new Size(192, 43);
            btnAtualizar.TabIndex = 12;
            btnAtualizar.Text = "Atualizar";
            btnAtualizar.Click += btnAtualizar_Click;
            // 
            // btnCadastrar
            // 
            btnCadastrar.BackColor = Color.Transparent;
            btnCadastrar.BorderRadius = 20;
            btnCadastrar.CustomizableEdges = customizableEdges6;
            btnCadastrar.DisabledState.BorderColor = Color.DarkGray;
            btnCadastrar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCadastrar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCadastrar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCadastrar.FillColor = Color.DarkSeaGreen;
            btnCadastrar.Font = new Font("Ravie", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCadastrar.ForeColor = Color.Black;
            btnCadastrar.Location = new Point(3, 431);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.ShadowDecoration.CustomizableEdges = customizableEdges7;
            btnCadastrar.Size = new Size(192, 45);
            btnCadastrar.TabIndex = 13;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnFechar
            // 
            btnFechar.BackColor = Color.Transparent;
            btnFechar.BorderColor = Color.Brown;
            btnFechar.DisabledState.BorderColor = Color.DarkGray;
            btnFechar.DisabledState.CustomBorderColor = Color.DarkGray;
            btnFechar.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnFechar.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnFechar.FillColor = Color.Transparent;
            btnFechar.Font = new Font("Ravie", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnFechar.ForeColor = Color.Red;
            btnFechar.Location = new Point(646, 1);
            btnFechar.Name = "btnFechar";
            btnFechar.ShadowDecoration.CustomizableEdges = customizableEdges1;
            btnFechar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnFechar.Size = new Size(42, 29);
            btnFechar.TabIndex = 24;
            btnFechar.Text = "X";
            btnFechar.Click += btnFechar_Click;
            // 
            // frmPratos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(148, 84, 204);
            ClientSize = new Size(700, 488);
            Controls.Add(btnFechar);
            Controls.Add(btnExcluir);
            Controls.Add(btnAtualizar);
            Controls.Add(btnCadastrar);
            Controls.Add(txtPreco);
            Controls.Add(txtNome);
            Controls.Add(txtCod);
            Controls.Add(txtPesquisar);
            Controls.Add(dgProdutos);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmPratos";
            Text = "frmPratos";
            Load += frmPratos_Load;
            ((System.ComponentModel.ISupportInitialize)dgProdutos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2TextBox txtPesquisar;
        private Guna.UI2.WinForms.Guna2DataGridView dgProdutos;
        private Guna.UI2.WinForms.Guna2TextBox txtCod;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtPreco;
        private Guna.UI2.WinForms.Guna2TextBox txtNome;
        private Guna.UI2.WinForms.Guna2Button btnExcluir;
        private Guna.UI2.WinForms.Guna2Button btnAtualizar;
        private Guna.UI2.WinForms.Guna2Button btnCadastrar;
        private Guna.UI2.WinForms.Guna2CircleButton btnFechar;
    }
}