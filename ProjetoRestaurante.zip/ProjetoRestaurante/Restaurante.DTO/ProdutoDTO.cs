﻿namespace Restaurante.DTO
{
    public class ProdutoDTO
    {
        public int Cod {  get; set; }
        public string Nome { get; set; } = string.Empty;
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
        public string? UrlFoto { get; set; }
     


    }
}
