﻿namespace Restaurante.DTO
{
    public class BebidaDTO : ProdutoDTO
    {
       
    }
}
