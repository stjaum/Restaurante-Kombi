﻿namespace Restaurante.DTO
{
    public abstract class PessoaDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string? UrlFoto { get; set; }
        public string Email { get; set; } = string.Empty;
        public string Senha { get; set; }

        public string DataDeAdmissão { get; set; } = string.Empty;


    }
    
}
//Id, Nome, Email, Senha, Cargo/TipoUsuario Data de Admissão