﻿namespace Restaurante.DTO
{
    public class UsuarioDTO : PessoaDTO
    {
        public string Cargo { get; set; } 

        public string TipoUsuario { get; set; } = string.Empty;
    }
}
