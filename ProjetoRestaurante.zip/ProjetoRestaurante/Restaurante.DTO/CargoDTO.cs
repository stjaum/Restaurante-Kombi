﻿namespace Restaurante.DTO
{
    public class CargoDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;

     

    }
}
