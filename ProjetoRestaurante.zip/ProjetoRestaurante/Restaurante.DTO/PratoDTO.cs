﻿namespace Restaurante.DTO
{
    public class PratoDTO : ProdutoDTO
    {
      


    }
}
