﻿namespace Restaurante.DTO
{
    public class SobremesaDTO : ProdutoDTO
    {
    }
}
