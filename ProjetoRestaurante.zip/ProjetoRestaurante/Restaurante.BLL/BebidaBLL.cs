﻿using Restaurante.DTO;
using Restaurante.DAL;

namespace Restaurante.BLL
{
    public class BebidaBLL : BebidaDTO
    {
        public void CadastrarBebida(BebidaDTO bebida)
        {
            bebida.Cod = DataBase.Bebidas.Any() ? DataBase.Bebidas.Max(bebida => bebida.Cod) + 1 : 1;

            if (string.IsNullOrWhiteSpace(bebida.Nome))
            {
                throw new Exception("Nome da bebida é obrigatório!");
            }
            var bebidas = DataBase.Bebidas;

            bebidas.Add(bebida);
            DataBase.Bebidas.Add(bebida);
        }
        public List<BebidaDTO> ListarBebidas() => DataBase.Bebidas;
        
        public void AtualizarBebida(BebidaDTO bebidaDTO)
        {
            var bebidaExistente = DataBase.Bebidas.FirstOrDefault(bebida => bebida.Cod == bebidaDTO.Cod);

            if(bebidaExistente == null)
            {
                throw new Exception("Bebida não encontrada!");
            }

            if (string.IsNullOrWhiteSpace(bebidaDTO.Nome))
            {
                throw new Exception("Nome da bebida é obrigatório!");

            }
            bebidaExistente.Nome = bebidaDTO.Nome;
            bebidaExistente.Descricao = bebidaDTO.Descricao;
            bebidaExistente.Preco = bebidaDTO.Preco;
            
        }
        public void RemoverBebida(string nome)
        {
            var bebida = DataBase.Bebidas.FirstOrDefault(u => u.Nome == Nome);

            if (bebida == null)
            {
                throw new Exception("Bebidas não encontrado!");
            }
            DataBase.Bebidas.Remove(bebida);

        }
    }
}
