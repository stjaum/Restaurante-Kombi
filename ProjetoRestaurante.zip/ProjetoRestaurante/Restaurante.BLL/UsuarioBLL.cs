﻿using Restaurante.DAL;
using Restaurante.DTO;

namespace Restaurante.BLL
{
    public class UsuarioBLL : UsuarioDTO
    {
        public List<UsuarioDTO> ListarUsuarios() => DataBase.Usuarios;
        public void CadastrarUsuario(UsuarioDTO usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.Nome))
            {
                throw new Exception("Nome é obrigatório!");
            }

            if (string.IsNullOrWhiteSpace(usuario.Email))
            {
                throw new Exception("Email é obrigatório!");
            }

            if (string.IsNullOrWhiteSpace(usuario.Senha))
            {
                throw new Exception("Senha é obrigatório!");
            }
            var usuarios = DataBase.Usuarios;

            usuarios.Add(usuario);
            DataBase.Usuarios.Add(usuario);


        }
        public UsuarioDTO? Email(string email, string senha)
        {
            var usuario = DataBase.Usuarios.FirstOrDefault(u => u.Email == email && u.Senha == senha);

            if (usuario == null)
            {
                throw new Exception("Usuário ou senha inválidos!");
            }
            return usuario;
        }
        public void RemoverUsuario(string nome)
        {
            var usuario = DataBase.Usuarios.FirstOrDefault(u => u.Nome == Nome);

            if (usuario == null)
            {
                throw new Exception("Usuário não encontrado!");
            }
            DataBase.Usuarios.Remove(usuario);
        }
        public void AtualizarUsuario(UsuarioDTO usuarioDTO)
        {
            var usuarioExistente = DataBase.Usuarios.FirstOrDefault(usuario => usuario.Id == usuarioDTO.Id);

            if (usuarioExistente == null)
            {
                throw new Exception("Usuário não encontrada!");
            }

            if (string.IsNullOrWhiteSpace(usuarioDTO.Nome))
            {
                throw new Exception("Nome do Usuário é obrigatório!");

            }
            usuarioExistente.Nome = usuarioDTO.Nome;
            usuarioExistente.Email = usuarioDTO.Email;
            usuarioExistente.Senha = usuarioDTO.Senha;
            usuarioExistente.UrlFoto = usuarioDTO.UrlFoto;
        }
    }
}
