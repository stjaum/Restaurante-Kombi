﻿using Restaurante.DAL;
using Restaurante.DTO;

namespace Restaurante.BLL
{
    public class PratoBLL : PratoDTO
    {
        public void CadastrarPrato(PratoDTO prato)
        {
            prato.Cod = DataBase.Pratos.Any() ? DataBase.Pratos.Max(prato => prato.Cod) + 1 : 1;

            if (string.IsNullOrWhiteSpace(prato.Nome))
            {
                throw new Exception("Nome do Prato é obrigatório!");
            }
            var pratos = DataBase.Pratos;

            pratos.Add(prato);
            DataBase.Pratos.Add(prato);
        }
        public List<PratoDTO> ListarPratos() => DataBase.Pratos;
        public void AtualizarPrato(PratoDTO pratoDTO)
        {
            var pratoExistente = DataBase.Pratos.FirstOrDefault(prato => prato.Cod == pratoDTO.Cod);

            if (pratoExistente == null)
            {
                throw new Exception("Prato não encontrado!");
            }

            if (string.IsNullOrWhiteSpace(pratoDTO.Nome))
            {
                throw new Exception("Nome do prato é obrigatório!");

            }

            pratoExistente.Nome = pratoDTO.Nome;
            pratoExistente.Preco = pratoDTO.Preco;

        }
        public void RemoverPrato(string nome)
        {
            var prato = DataBase.Pratos.FirstOrDefault(u => u.Nome == Nome);

            if (prato == null)
            {
                throw new Exception("Prato não encontrado!");
            }
            DataBase.Pratos.Remove(prato);

        }
    }
}
