﻿using Restaurante.DAL;
using Restaurante.DTO;

namespace Restaurante.BLL
{
    public class SobremesaBLL : SobremesaDTO
    {
        public void CadastrarSobremesa(SobremesaDTO sobremesa)
        {
            sobremesa.Cod = DataBase.Sobremesas.Any() ? DataBase.Sobremesas.Max(sobremesa => sobremesa.Cod) + 1 : 1;

            if (string.IsNullOrWhiteSpace(sobremesa.Nome))
            {
                throw new Exception("Nome da sobremesa é obrigatório!");
            }
            var sobremesas = DataBase.Sobremesas;

            sobremesas.Add(sobremesa);
            DataBase.Sobremesas.Add(sobremesa);
        }
        public List<SobremesaDTO> ListarSobremesa() => DataBase.Sobremesas;
        public void AtualizarSobremesa(SobremesaDTO sobremesaDTO)
        {
            var sobremesaExistente = DataBase.Sobremesas.FirstOrDefault(sobremesa => sobremesa.Cod == sobremesaDTO.Cod);

            if (sobremesaExistente == null)
            {
                throw new Exception("Sobremesa não encontrada!");
            }

            if (string.IsNullOrWhiteSpace(sobremesaDTO.Nome))
            {
                throw new Exception("Nome da sobremesa é obrigatório!");

            }

            sobremesaExistente.Nome = sobremesaDTO.Nome;
            sobremesaExistente.Preco = sobremesaDTO.Preco;

        }
        public void RemoverSobremesa(string nome)
        {
            var sobremesa = DataBase.Sobremesas.FirstOrDefault(u => u.Nome == Nome);

            if (sobremesa == null)
            {
                throw new Exception("Sobremesa não encontrado!");
            }
            DataBase.Sobremesas.Remove(sobremesa);

        }
    }
}
